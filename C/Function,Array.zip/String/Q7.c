//7. Write a program in C to copy one string to another string.
#include <stdio.h>
#include<string.h>
int main(){
	char string[50],copystr[50];
	//input string
	printf("Enter a string:");
	//gets and read a string
	gets(string);
	strcpy(copystr,string); 
	//print copied string 
	printf("copied string is:%s",copystr);    
}
