//2. WAP to accept 5 numbers from user and display all numbers
#include<stdio.h>
int main(){
	int i,num=0;
	//for loop for 5 numbers 
	for(i=1;i<=5;i++){
	printf("Enter number:",i);	
	scanf("%d",&num);
	printf("%d\n",num);
	}
}
